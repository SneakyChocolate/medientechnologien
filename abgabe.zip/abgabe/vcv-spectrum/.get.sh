# tri
wget -q -O "tri-0.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304446339437826099/image.png?ex=6737fd92&is=6736ac12&hm=15fece61b673fbca50a7b43ae5a40a957c46a0ab77aceef87ad33f8589d306da&"
wget -q -O "tri-1.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304446384610607144/image.png?ex=6737fd9d&is=6736ac1d&hm=0daf47d4119a58eea9eba3012c73ee120b8c71114ecc99bac5686131f28c0092&"
wget -q -O "tri-2.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304446484392968252/image.png?ex=6737fdb5&is=6736ac35&hm=be00293a7ea4483356290deaf70e25be00cb3f5c61221b80cab5317854369127&"
wget -q -O "tri-3.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304446579901468712/image.png?ex=6737fdcc&is=6736ac4c&hm=074e471c6a0c5f53959a93aa66bb73e54fa3aeae6f99022f3d07f927caa5334b&"

# saw
wget -q -O "saw-0.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304446767227605135/image.png?ex=6737fdf8&is=6736ac78&hm=04b21c88d970f7f3c8e399aed979ad843830ddf30b2622ef3ca2451c7607e3ed&"
wget -q -O "saw-1.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304446813092184084/image.png?ex=6737fe03&is=6736ac83&hm=0cea8e437abcc225b5d1a9b45ce89e354d07617ea61350e910cd76c3893a9da2&"
wget -q -O "saw-2.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304446857958654004/image.png?ex=6737fe0e&is=6736ac8e&hm=39ceb9808fb22b00394e1430bf4c8a1165428980568e443ce05ed78782745282&"
wget -q -O "saw-3.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304446894906408970/image.png?ex=6737fe17&is=6736ac97&hm=67fb1d41963719beaabaee3e86eb117be4bf67dba00dbe0c077a2adfa9096b26&"

# sqr
wget -q -O "sqr-0.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304447000640622663/image.png?ex=6737fe30&is=6736acb0&hm=05c53618a804b58873fdab2d277322dda9f06ba3a4f905ee619476b66fc191b1&"
wget -q -O "sqr-1.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304447036011057235/image.png?ex=6737fe38&is=6736acb8&hm=4cc6f3a97779926a378af807eab6999a7b3d6bd7c8eefd7ff49411b1dea3a342&"
wget -q -O "sqr-2.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304447066025492542/image.png?ex=6737fe3f&is=6736acbf&hm=9654de2135a139f1b2da890ee354c41fe201304d13923f9c9468ab1bd53a41c2&"
wget -q -O "sqr-3.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1304447122539548722/image.png?ex=6737fe4d&is=6736accd&hm=e413fb20b2e5a120670869a25de68db88171077f298476a22df36cc197b6492c&"

# sqr 10
wget -q -O "sqr-10-0.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1306906075294863370/image.png?ex=67385ea1&is=67370d21&hm=03babd855e133d00eee2c8727e2a18f7aafb02333abe4449ae927f45dc490980&"
wget -q -O "sqr-10-1.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1306906164981923860/image.png?ex=67385eb6&is=67370d36&hm=f134443691d80038623755c64470573792de2a408d054929d0a1442cc38df793&"
wget -q -O "sqr-10-2.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1306906202873004112/image.png?ex=67385ebf&is=67370d3f&hm=8d993b4261a4aa67690398e293185ffab50652309ad647089f29a9975fed6b0d&"
wget -q -O "sqr-10-3.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1306906240395382805/image.png?ex=67385ec8&is=67370d48&hm=0b97a47779dc1b8e222394ee9c2b0ae7bbf2c6891a4ad13d22a86b825f458701&"

# sqr 30
wget -q -O "sqr-30-0.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1306906398411456512/image.png?ex=67385eee&is=67370d6e&hm=79ba25f459c7c19a8b8aeb80173ff38425675927ccac39b797b89f6c0a135757&"
wget -q -O "sqr-30-1.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1306906468905254952/image.png?ex=67385eff&is=67370d7f&hm=54a68bed09c6096658425aeb75b81d5a7212a1e6b1491455c8ed453f6edea4c9&"
wget -q -O "sqr-30-2.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1306906518108766208/image.png?ex=67385f0b&is=67370d8b&hm=f05e7e413b9af0a5e80e2399fdaeb06045d574cd0b731381cc62351a757ef20d&"
wget -q -O "sqr-30-3.png" "https://cdn.discordapp.com/attachments/1304430794864988221/1306906564883513364/image.png?ex=67385f16&is=67370d96&hm=707fec3ad01730d536fc043198bba371fc78171dd90254ca340f378495312e24&"
